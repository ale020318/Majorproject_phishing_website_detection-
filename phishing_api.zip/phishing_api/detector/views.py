from rest_framework.decorators import api_view
from rest_framework.response import Response
import pickle
import pandas as pd
import re
import os

# Load model and scaler from root directory
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "DecisionTreeClassifier.pickle.dat")
SCALER_PATH = os.path.join(BASE_DIR, "scaler.pickle.dat")

with open(MODEL_PATH, "rb") as model_file:
    model = pickle.load(model_file)

with open(SCALER_PATH, "rb") as scaler_file:
    scaler = pickle.load(scaler_file)

def preprocess_url(url):
    return pd.DataFrame({
        'length': [len(url)],
        'num_digits': [len(re.findall(r'\d', url))],
        'num_special_chars': [len(re.findall(r'\W', url))],
        'has_http': [1 if 'http' in url else 0],
        'has_https': [1 if 'https' in url else 0]
    })

@api_view(['POST'])
def predict_url(request):
    urls = request.data.get("urls", [])
    result = []

    for url in urls:
        df = preprocess_url(url)
        scaled = scaler.transform(df)
        prediction = model.predict(scaled)[0]
        result.append({
            "url": url,
            "prediction": "Phishing" if prediction == 1 else "Safe"
        })

    return Response(result)
