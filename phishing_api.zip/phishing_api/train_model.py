import pandas as pd
import pickle
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler

data = {
    'length': [30, 40, 20, 35],
    'num_digits': [3, 5, 2, 1],
    'num_special_chars': [2, 3, 0, 1],
    'has_http': [1, 0, 1, 0],
    'has_https': [0, 1, 0, 1],
    'label': [0, 1, 0, 1]
}
df = pd.DataFrame(data)

X = df.drop('label', axis=1)
y = df['label']

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

model = DecisionTreeClassifier()
model.fit(X_scaled, y)

pickle.dump(model, open(".pickle.dat", "wb"))
pickle.dump(scaler, open("scaler.pickle.dat", "wb"))
