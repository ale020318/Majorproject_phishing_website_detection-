document.getElementById("checkBtn").addEventListener("click", async () => {
    const urlInput = document.getElementById("urlInput").value;
    const urls = urlInput.split(",").map(u => u.trim());
    const resultDiv = document.getElementById("result");
    resultDiv.innerHTML = "Checking...";
  
    const response = await fetch("http://127.0.0.1:8000/api/predict/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ urls: urls })
    });
  
    const data = await response.json();
    resultDiv.innerHTML = data.map(d => `<p>${d.url} - <strong>${d.prediction}</strong></p>`).join("");
  });
  